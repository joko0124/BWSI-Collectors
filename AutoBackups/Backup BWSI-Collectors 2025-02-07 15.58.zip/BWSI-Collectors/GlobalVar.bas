﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10
@EndOfDesignText@
'Code module
'Subs in this code module will be accessible from all modules.
Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Public PriColor As Double = 0xFF16406E
	Public SecColor As Double = 0xFF158CC4
	
	Public SF as StringFunctions
End Sub